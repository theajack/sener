/*
 * @Author: chenzhongsheng
 * @Date: 2023-02-18 14:59:17
 * @Description: Coding something
 */
// import fs from 'fs';

// const TOKEN = 'bd222807b93e684654284a8b3a30476c'; // md5 of tackchen

// export function addWhiteList () {
//     return fs.readFileSync('src/db/white-list/tc-comment.json');
// }